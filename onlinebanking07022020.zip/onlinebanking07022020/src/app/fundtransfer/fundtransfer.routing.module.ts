import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {NeftComponent} from "./neft/neft.component";
import {RtgsComponent} from "./rtgs/rtgs.component";
import {ImpsComponent} from "./imps/imps.component";



const routes: Routes = [
  {
    path:'NEFT',
    component:NeftComponent
  },
  {
    path:'RTGS',
    component:RtgsComponent
  },
  {
    path:'IMPS',
    component: ImpsComponent

  }

];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundTransferRoutingModule { }
