import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
// @ts-ignore
import * as opecData from '../../opec.json'
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {MatTableDataSource} from "@angular/material/table";
import {MatDialog} from "@angular/material/dialog";
import {EditviewComponent} from "./editview/editview.component";
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit,AfterViewInit {
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  tableSource = new MatTableDataSource();
  displayedColumns: string[] = [ '0', '1','edit','delete'];

  constructor(private dialog:MatDialog) {


  }

  ngOnInit() {
    console.log(opecData.dataset.data);
    this.tableSource.data=opecData.dataset.data;
  }
  ngAfterViewInit() {
    this.tableSource.paginator = this.paginator;
    this.tableSource.sort = this.sort;

  }

  openDialog(obj)
  {

    const dialogRef= this.dialog.open(EditviewComponent,{
        width: '500px',
        data: {
          date:obj[0],
          value: obj[1]
        }
      });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      this.updateRowData(result);
    });

  }
  updateRowData(row_obj){
    this.tableSource.data = this.tableSource.data.filter((obj:any)=>{
      if(obj[0] == row_obj.date){
        obj[1] = row_obj.value;

      }
      return true;
    });
  }

  deleteRowData(row_obj){

    this.tableSource.data = this.tableSource.data.filter((value:any)=>{
      return value[0] != row_obj[0];
    });

  }



}
