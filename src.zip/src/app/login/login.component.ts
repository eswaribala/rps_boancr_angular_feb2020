import { Component, OnInit } from '@angular/core';
import {User} from "../models/user";
import {LoginService} from "../services/login.service";
import {Router} from "@angular/router";
import {AuthService} from "../services/auth.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

   user=new User("","");
   //service dependency injection
  constructor(private loginService:LoginService,
              private router:Router,private authService:AuthService) { }

  ngOnInit() {
  }

  login(event)
  {
    event.preventDefault();
    console.log(this.user);

    this.loginService.checkUserExistence(this.user).subscribe(response=>{
      console.log(response);
      this.newUser();
      if(response.email!=null)
        this.authService.token=response.email;
      if(this.authService.isLoggedIn)
         this.router.navigate(["/Home"]);
      else
        this.router.navigate(["/Login"]);
    })
  }


  newUser() {
    this.user = new User('','');
  }
}
